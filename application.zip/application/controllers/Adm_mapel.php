<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Adm_mapel	 extends CI_Controller {

	function __construct() {
    	parent::__construct();
    	$this->load->model('Model_mapel');
        if(empty($this->session->userdata('adm_login')))
        {
            redirect("login");
        }
    }

    function index()
    {
    	$dataHeader = array(
    		'title' => "Mata Pelajaran - Administrator"
    	);
    	$dataKonten = array(
    		'dataMapel' => $this->Model_mapel->list_mapel()->result()
    	);
    	$this->load->view('admin/header', $dataHeader);
    	$this->load->view('admin/mapel/main', $dataKonten);
    	$this->load->view('admin/footer');
    }
}
?>