<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard	 extends CI_Controller {

	function __construct() {
    	parent::__construct();
        if(empty($this->session->userdata('usr_login')))
        {
            redirect("login");
        }
    }

    function index()
    {
    	$dataHeader = array(
    		'title' => "Dashboard"
    	);
    	$this->load->view('header', $dataHeader);
    	$this->load->view('dashboard');
    	$this->load->view('footer');
    }
}
?>