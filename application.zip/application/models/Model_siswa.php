<?php 

class Model_siswa extends CI_Model{

	function list_siswa()
	{
		$this->db->select('*');
		return $this->db->get('siswa');
	}

	function json_siswa($nis)
	{
		$this->db->where('nis', $nis);
		return $this->db->get('siswa');
	}

	function act_editsiswa($data = array())
	{
		$this->db->set($data);
		$this->db->where('nis', $data['nis']);
		return $this->db->update('siswa');
	}

	function hapus_siswa($nis)
	{
		$this->db->where('nis', $nis);
		return $this->db->delete('siswa');
	}

	function tambah_siswa($data = array())
	{
		$this->db->set($data);
		return $this->db->insert('siswa');
	}
}
?>