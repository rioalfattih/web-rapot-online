<?php 

class Model_dashboard extends CI_Model{

	
}
?>