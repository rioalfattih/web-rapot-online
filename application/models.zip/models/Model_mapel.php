<?php 

class Model_mapel extends CI_Model{

	function list_mapel()
	{
		$this->db->select('*');
		return $this->db->get('mapel');
	}
}
?>