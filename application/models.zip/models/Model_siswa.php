<?php 

class Model_siswa extends CI_Model{

	function list_siswa()
	{
		$this->db->select('*');
		return $this->db->get('siswa');
	}

	function json_siswa($nis)
	{
		$this->db->where('nis', $nis);
		return $this->db->get('siswa');
	}

	function act_editsiswa($data = array())
	{
		$this->db->set($data);
		$this->db->where('nis', $data['nis']);
		return $this->db->update('siswa');
	}

	function hapus_siswa($nis)
	{
		$this->db->where('nis', $nis);
		return $this->db->delete('siswa');
	}

	function tambah_siswa($data = array())
	{
		$this->db->set($data);
		return $this->db->insert('siswa');
	}

	function ambil_kelas()
	{
		$this->db->order_by('id_kelas', 'DESC');
		return $this->db->get('kelas');
	}

	function default_isi_kelas()
	{
		$this->db->select('siswa.*, kelas.kelas');
		$this->db->join('nilai_siswa', 'siswa.nis=nilai_siswa.nis');
		$this->db->join('kelas', 'kelas.id_kelas=nilai_siswa.id_kelas');
		$this->db->group_by('nilai_siswa.nis');
		return $this->db->get('siswa');
	}

	function isi_kelas($id)
	{
		$this->db->select('siswa.*, kelas.kelas');
		$this->db->join('nilai_siswa', 'siswa.nis=nilai_siswa.nis');
		$this->db->join('kelas', 'kelas.id_kelas=nilai_siswa.id_kelas');
		$this->db->where('kelas.id_kelas', $id);
		$this->db->group_by('nilai_siswa.nis');
		return $this->db->get('siswa');
	}
}
?>