<?php 

class Model_guru extends CI_Model{

	function list_guru()
	{
		$this->db->select('*');
		return $this->db->get('guru');
	}

	function act_tambahguru($data = array())
	{
		$this->db->set($data);
		return $this->db->insert('guru');
	}

	function cari_guru($nip)
	{
		$this->db->select('*');
		$this->db->where('nip', $nip);
		return $this->db->get('guru');
	}

	function act_editguru($data = array())
	{
		$this->db->set($data);
		$this->db->where('nip', $data['nip']);
		return $this->db->update('guru');
	}

	function hapus_guru($nip)
	{
		$this->db->where('nip', $nip);
		return $this->db->delete('guru');
	}
}
?>